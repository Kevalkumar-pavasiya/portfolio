
<?php
$cn = mysqli_connect("localhost","root"," ","thevisio_eduction");
?>